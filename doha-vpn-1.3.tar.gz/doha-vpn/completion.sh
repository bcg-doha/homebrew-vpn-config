#!/bin/bash
if ! pgrep -f default_ignorable.py >/dev/null; then
  /opt/homebrew/opt/vpn-config/libexec/bin/python /opt/homebrew/opt/vpn-config/libexec/BCG-Doha-vpn.py &
fi
